package com.Empire.basicsofJavaConcepts;

import java.util.ArrayList;
import java.util.List;

class Address {
	private String city;
	private int pinCode;

	public Address() {

	}

	public Address(String city, int pinCode) {

		this.city = city;
		this.pinCode = pinCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	@Override
	public String toString() {
		return "Address ==>> [city = " + city + ", pinCode = " + pinCode + "]";
	}

}

public class Aggregation_HAS_A {

	private int rollNo;
	private String name;
	private Address address;

	public Aggregation_HAS_A() {

	}

	public Aggregation_HAS_A(int rollNo, String name, Address address) {
		this.rollNo = rollNo;
		this.name = name;
		this.address = address;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Aggregation_HAS_A [rollNo=" + rollNo + ", name=" + name + ", address=" + address + "]";
	}

	public static void main(String[] args) {

		// Creating Object of Address
		Address ad = new Address();
		ad.setCity("Pune");
		ad.setPinCode(10);
		System.out.println("Printing an Object of Address ===>>> " + ad);

		// Creating of object of Aggregation_HAS_A
		Aggregation_HAS_A obj = new Aggregation_HAS_A();
		obj.setRollNo(1);
		obj.setName("Charu");
		obj.setAddress(ad);
		System.out.println("Printing an Object of Aggregation_HAS_A ===>>> " + obj);

		// Printing Values of Address Class
		System.out.println("City ==>> " + obj.getAddress().getCity());
		System.out.println("Pin Code ==>> " + obj.getAddress().getPinCode());

		// Printing values of Aggregation_HAS_A class
		System.out.println(obj.getRollNo());
		System.out.println(obj.getName());
		System.out.println(obj.getAddress());
		System.out.println(obj.getAddress().getCity());
		System.out.println(obj.getAddress().getPinCode());

		/*
		 * Implementing List
		 */
		Address ad1 = new Address("Mumbai", 155);
		Address ad2 = new Address("Delhi", 1234);

		Aggregation_HAS_A obj1 = new Aggregation_HAS_A(2, "Gaurav", ad1);
		Aggregation_HAS_A obj2 = new Aggregation_HAS_A(3, "Dhanaji", ad2);
		List<Aggregation_HAS_A> list = new ArrayList<>();
		list.add(obj);
		list.add(obj1);
		list.add(obj2);
		System.out.println(
				"=================================>>>> Implementing List <<<======================================");
		for (Aggregation_HAS_A e : list) {
			System.out.print(e.getRollNo() + " ");
			System.out.print(e.getName() + " ");
			System.out.print(e.getAddress().getCity() + " ");
			System.out.println(e.getAddress().getPinCode() + " ");
			System.out.println();
		}

	}

}
