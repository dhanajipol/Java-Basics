package com.Empire.basicsofJava.operators;

public class ArithmeticOperator {

	public static void main(String[] args) {

		/*
		 * Operation =(OPerand1) [Operator] (Operand2)
		 * 
		 * Arithmetic Operator :- 1) add(Plus) Operator (+) 2) minus Operator (-) 3)
		 * multiplication Operator (*) 4) Divide operator (/) 5) modulo Operator (%)
		 */

		// Adding 2 Values by + Operator and Storing Result into third variable
		int result = 10 + 5;
		System.out.println("Addition is = " + result);

		// Operation on Stored Values
		int numOne = 20, numTwo = 10;
		result = numOne + numTwo;
		System.out.println("Addition of Two Values " + result);

		result = numOne + 10;
		System.out.println("Value Stored in numOne Variable is added to the 10 = " + result);

		// Operation within print Statement
		System.out.println("Performing Operation in print Statement = " + (result = 10 + 15));

		// Subtracting two values & Storing to Third Variable
		result = 10 - 5;
		System.out.println("Subtracttion 2 Values is = " + result);

		// Subtracting 2 Values which is stored in variable
		numOne = 15;
		numTwo = 5;
		result = numOne - numTwo;
		System.out.println("Subtraction is = " + result);

		// Multiplication

		numOne = 10;
		numTwo = 5;
		result = numOne * numTwo;
		System.out.println("Mulitplication is = " + result);

		result = numOne * 2;
		System.out.println(result);

		// Division

		numOne = 10;
		numTwo = 5;
		result = numOne / numTwo;
		System.out.println("Division is = " + result);

		// Remainder / modulo

		numOne = 8;
		numTwo = 5;
		result = numOne % numTwo;
		System.out.println("Remainder is = " + result);

		System.out.println(10 % 2);
		System.out.println(numTwo);

	}
}
