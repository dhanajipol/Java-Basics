package com.Empire.basicsofJava.operators;

public class AssignmentOperator {

	public static void main(String[] args) {

		/*
		 * Assignment Operator: 
		 * 1) Equal :-  =
		 * 2) plus Equal :- +=
		 * 3) Minus Equal :- -=
		 * 4) Multiply Equal:-  *=
		 * 5) Divide Equal :- /=
		 * 6) Remainder Equal:- %=
		 * 
		 */

		// Equal
		int numOne = 10;
		int numTwo = numOne;
		System.out.println("numOmne " + numOne + " " + "numTwo " + numTwo);
 
		// += 
		numOne += 30; 					// numOne = numOne + 30;
		System.out.println(numOne);

		int var1 = 5;
		var1 += 50; 				// var1 = var1+ var2; // var += var2;
		System.out.println(var1);
			
		// -=
		int var3 = 10, var4 = 5;
		var3 -= var4; //
		System.out.println(var3);
		
		
		
		// *=
		int var5 = 5, var6 = 2;
		var5 *= var6;
		System.out.println(var5);

		
		
		// (/=)
		int var7 = 10, var8 = 3;
		var7 /= var8; 
		System.out.println(var7);
		
		
		// %=
		int num1 = 8, num2 = 3;
		num1 %= num2;    					// num1 %= num2;
		System.out.println(num1);
		

	}

}
