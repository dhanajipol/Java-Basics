package com.Empire.basicsofJava.operators;

public class BitwiseOperator {

	public static void main(String[] args) {

		/*
		 * Bitwise Operator :- &, |
		 * 
		 * 
		 * 
		 */

		/*
		 * Bitwise AND (&) This Operator Will find out the Binary of First Variable and
		 * Second Variable And then it will perform AND Operation on it
		 */
		System.out.println("Bitwise AND Operator = " + (4 & 5));
		int numOne = 10, numTwo = 15;
		System.out.println("Bitwise AND Operator = " + (numOne & numTwo));

		System.out.println("================================******====================================");

		// Bitwise OR Operator (|)

		System.out.println("Bitwise OR Operator = " + (4 | 5));
		System.out.println("Bitwise OR Operator = " + (numOne | numTwo));
	}
}