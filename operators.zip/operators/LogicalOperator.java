package com.Empire.basicsofJava.operators;

public class LogicalOperator {

	public static void main(String[] args) {

		/*
		 * Logical Operator :- &&, ||, !
		 */

		// Logical AND (&&)
		System.out.println("Implementing LOGICAL AND Operator = " + ((true) && (true)));
		System.out.println("Implementing LOGICAL AND Operator = " + ((5 < 10) && (100 > 50)));

		int numOne = 10, numTwo = 20;
		System.out.println("Implementing LOGICAL AND Operator = " + ((numOne > numTwo) && (numOne < numTwo)));

		System.out.println("================================******====================================");

		// Logical OR (||)
		System.out.println("Implementing LOGICAL OR Operator = " + ((numOne > numTwo) || (numOne < numTwo)));

		System.out.println("================================******====================================");

		// Logical NOT (!)
		System.out.println("Implementing LOGICAL NOT Operator = " + !(true));
		System.out.println("Implementing LOGICAL NOT Operator = " + !(false));
		
		
	}

}
