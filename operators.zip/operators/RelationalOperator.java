package com.Empire.basicsofJava.operators;

public class RelationalOperator {

	public static void main(String[] args) {

		/*
		 * Relational Operators :- (return boolean values) 
		 * 1) == (equal to) 
		 * 2) < (less than) 
		 * 3) > (greater than) 
		 * 4) <= (less than equal to) 
		 * 5) >= (greater than equal to) 
		 * 6) != (Not equal to)
		 * 
		 */

		// equal to (==) ==> It will compare 2 values, if both are equal then it return
		// true otherwise it will return false
		int numOne, numTwo;

		numOne = 10;
		numTwo = 5;
		System.out.println(numOne == numTwo);

		numOne = 10;
		numTwo = 10;
		System.out.println(numOne == numTwo);

		// less than ==>> It will check first values is less than second value , is yes
		// it will return true otherwise it will return false
		numOne = 20;
		numTwo = 30;
		System.out.println(numOne < numTwo);

		// greater than (>) ===>> It will check first value is greater than secon value,
		// if yes then it will return true otherwise it will return false
		 System.out.println(numOne > numTwo);
		 
		 
		// Not Equal to (!=)
			
		System.out.println(numOne != numTwo);

	}
}
