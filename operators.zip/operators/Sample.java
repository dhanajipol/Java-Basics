package com.Empire.basicsofJava.operators;

public class Sample {

	public static void main(String[] args) {
		System.out.println();
	}
}
