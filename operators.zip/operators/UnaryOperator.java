package com.Empire.basicsofJava.operators;

public class UnaryOperator {

	public static void main(String[] args) {

		/*
		  		Unary Operator :- 
		  				1) Increment Operator ====>>>>  ++
		  								A) Pre Increment ====>>> ++variable
		  								B) Post Increment ====>>> variable++
		  				2) Decrement Operator ====>>>>  --
		  								A) Pre Decrement ====>>> --variable
		  								B) Post Decrement ====>>> variable--
		 
		 */
		
		
		// Pre Increment 
		int num1 = 10;
		int result1 = ++num1;  // First it will update the value & then it will Use the value
		System.out.println("value of num1 Variable is = " + num1);
		System.out.println("value of result Variable is = " + result1);
		
		
		
		// Post Increment 
		int num2 = 10;
		int result2 = num2++;  // First it will Use the value & then it will Update the value
		System.out.println("value of num1 Variable is = " + num2);
		System.out.println("value of result Variable is = " + result2);
		
		int numOne = 10, numTwo =20;
		int result = (++numOne) + (numTwo++);    // numOne will increase by 1 = 11 & numTwo will add into numOne (11 + 20) and then numTwo will become 21
		System.out.println(result);
		System.out.println(numOne);
		System.out.println(numTwo);
		
	}

}
