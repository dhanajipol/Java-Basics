package com.Empire.basicsofJava.operators;

public class UseOfDataTypes {

	public static void main(String[] args) {

		/*
		 * This file is to understand the Data types in Java
		 * 
		 * There Are Total 2 types of Data types :- 
		 * 1} Primitive Data Types :-
		 * In Primitive Type, There Are Total 8 Data types present in JAVA
		 * 
		 * 1) Integer (int)
		 * 2) Short (short)
		 * 3) Long (long)
		 * 4) Byte (byte)
		 * 5) Character (char)
		 * 6) Float (float)
		 * 7) Double (double)
		 * 8) Boolean (boolean)
		 * 
		 * 2} Non- Primitive Data types :-
		 * 
		 * 1) String (String)
		 * 2) Array (array)
		 */
		
		
		
		// Below line will tell to the compiler that the actual data (10) which is of int type is going to be stored in num1 variable
		// "int" is data type, "num1" is name of variable , 10 is actual value or data
		// Size of int is 4 Bytes
		System.out.println("Size of INTEGER in Bytes ==>> " + Integer.BYTES);
		System.out.println("Size if INTEGER in Bits ==>> " + Integer.SIZE);
		System.out.println("Maximum Value of INTEGER ===>>> " + Integer.MAX_VALUE);
		System.out.println("Minimum Value of INTEGER ===>>> " + Integer.MIN_VALUE);
		
		int num1= 3950;
		System.out.println(num1);
		System.out.println("Bits of variable num1 ===>> " + Integer.bitCount(num1));
		System.out.println("Hashcode of num1 ==>> " + Integer.hashCode(num1));
		System.out.println("Highest bit of num1 ===>> " + Integer.highestOneBit(num1));
		System.out.println(Integer.numberOfLeadingZeros(num1));
		System.out.println(Integer.reverse(num1));
		System.out.println("Binary of num1 ===>> " + Integer.toBinaryString(num1));
		
		
		
		// Size of short is 2 Bytes
		System.out.println("Size of Short ===>> " + Short.BYTES);
		short num2 = 24;
		System.out.println(num2);
		
		//While presenting long type of variable we should provide L as suffix after value (example :- long var1 = 10L)
		// Size of Long is 8 Bytes 
		long num3 = 12834699245L;
		System.out.println(num3);
		
		
		//Size of byte is 1 Byte
		byte num4 = 1;
		System.out.println(num4);
		
		
		//While presenting Float type of variable we should provide f as suffix after value (example :- float var2 = 3.14f)
		// Size of Float is 4 bytes
		System.out.println(Float.BYTES);
		float num5 = 314.25f;
		System.out.println(num5);
		
		// Size of Double is 8 Bytes
		System.out.println(Double.BYTES);
		double num6= 38164518846.48541;
		System.out.println(num6);
		
		
		//Size of boolean is 1 Bit
		boolean var3 = true;
		System.out.println(var3);
		
		//Size of char is 2 Bytes
		System.out.println(Character.BYTES);
		System.out.println("Maximum value of Char ===>> " + Character.MAX_VALUE);
		char letter = 'G';
		System.out.println(letter);
		
		// Set of characters means String
		String name = "Gaurav";
		System.out.println(name);
		
		//Group of similar types of values is Array
		int[] group = {1,2,3,4,5};
		System.out.println(group);
	}

}
